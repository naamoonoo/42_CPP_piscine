#ifndef FT_FORWARD_HPP
#define FT_FORWARD_HPP

class forward
{
private:
	/* data */
public:
	static int p1_row;
	static int p1_col;
};

#endif /* FT_forward_HPP */
